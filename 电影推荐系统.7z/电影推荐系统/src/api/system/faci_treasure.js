import request from '@/utils/request'

// 查询faci_treasure change列表
export function listFaci_treasure(query) {
  return request({
    url: '/system/faci_treasure/list',
    method: 'get',
    params: query
  })
}

// 查询faci_treasure change详细
export function getFaci_treasure(id) {
  return request({
    url: '/system/faci_treasure/' + id,
    method: 'get'
  })
}

// 新增faci_treasure change
export function addFaci_treasure(data) {
  return request({
    url: '/system/faci_treasure',
    method: 'post',
    data: data
  })
}

// 修改faci_treasure change
export function updateFaci_treasure(data) {
  return request({
    url: '/system/faci_treasure',
    method: 'put',
    data: data
  })
}

// 删除faci_treasure change
export function delFaci_treasure(id) {
  return request({
    url: '/system/faci_treasure/' + id,
    method: 'delete'
  })
}
